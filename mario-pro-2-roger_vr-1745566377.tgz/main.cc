#include <vector>
#include "game.hh"
#include "window.hh"

using namespace std;

const int WIDTH = 480, HEIGHT = 320;
const int ZOOM = 3;
const int FPS = 48;

int main() {
    pro2::Window window("Mario & Luigi tornada a la uni", WIDTH, HEIGHT, ZOOM);
    window.set_fps(FPS);

    // void inciar_partida();
    Game game(WIDTH, HEIGHT);

    while (window.next_frame() && !game.is_finished()) {
        game.update(window);
        game.paint(window);
    }
}