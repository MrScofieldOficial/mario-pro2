#ifndef MARIO_HH
#define MARIO_HH

#include <iostream>
#include <vector>
#include "coffee.hh"
#include "platform.hh"
#include "coffee.hh"
#include "window.hh"
#include "utils.hh"

class Mario {
 private:
    pro2::Pt pos_, last_pos_, original_pos_;
    pro2::Pt speed_ = {0, 0};
    pro2::Pt accel_ = {0, 0};
    int      accel_time_ = 0;
    int      id_; // 0 = mario, 1 = luigi

    bool grounded_ = false;
    bool looking_left_ = false;
    bool jumping_ = false;
    bool rush_ = false;
    int rush_time_ = 0;
    int last_rush_ = 0;

    char jump_key_;
    char left_key_;
    char right_key_;

    void apply_physics_();

 public:
    Mario(pro2::Pt pos, int id)
        : pos_(pos),
          last_pos_(pos),
          original_pos_(pos),
          jump_key_(pro2::Keys::Up),
          left_key_(pro2::Keys::Left),
          right_key_(pro2::Keys::Right),
          id_(id) {}

    Mario(pro2::Pt pos, char jump_key, char left_key, char right_key, int id)
        : pos_(pos),
          last_pos_(pos),
          original_pos_(pos),
          jump_key_(jump_key),
          left_key_(left_key),
          right_key_(right_key),
          id_(id) {}

    void paint(pro2::Window& window) const;
    void jump(float mult);
    void update(pro2::Window& window, const std::vector<Platform>& platforms, std::vector<Coffee>& cafes, int& total_coffee);

    pro2::Pt pos() const {
        return pos_;
    }

    void set_y(int y) {
        pos_.y = y;
    }

    void set_x(int x) {
        pos_.x = x;
    }

    bool is_grounded() const {
        return grounded_;
    }

    void set_grounded(bool grounded) {
        grounded_ = grounded;
        if (grounded_) {
            speed_.y = 0;
        }
    }

    void toggle_grounded() {
        set_grounded(!grounded_);
    }

    void set_pos(pro2::Pt new_pos) {
        pos_ = new_pos;
    }
    
    pro2::Pt get_original_pos() {
        looking_left_ = false;
        return original_pos_;
    }

    void reset_rush () {
        last_rush_ = 0;
        rush_ = false;

    }

    pro2::Rect get_hit_box () {
        return {pos_.x - 3, pos_.y - 17, pos_.x + 11, pos_.y + 1};
    }

 private:
};

#endif